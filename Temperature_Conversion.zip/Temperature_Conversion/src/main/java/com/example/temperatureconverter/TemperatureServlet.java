package com.example.temperatureconverter;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TemperatureServlet")
public class TemperatureServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Retrieve temperature value and unit from the form
        String tempValue = request.getParameter("tempValue");
        String unit = request.getParameter("unit");

        // Parse temperature to double
        double temperature = Double.parseDouble(tempValue);

        // Variables to store conversion results
        double celsius = 0, fahrenheit = 0, kelvin = 0;

        // Perform conversions based on the input unit
        switch (unit) {
            case "Celsius":
                celsius = temperature;
                fahrenheit = (temperature * 9/5) + 32;
                kelvin = temperature + 273.15;
                break;
            case "Fahrenheit":
                celsius = (temperature - 32) * 5/9;
                fahrenheit = temperature;
                kelvin = celsius + 273.15;
                break;
            case "Kelvin":
                celsius = temperature - 273.15;
                fahrenheit = (celsius * 9/5) + 32;
                kelvin = temperature;
                break;
        }

        // Set attributes to pass to the JSP page
        request.setAttribute("celsius", celsius);
        request.setAttribute("fahrenheit", fahrenheit);
        request.setAttribute("kelvin", kelvin);

        // Forward the request to result.jsp for displaying the results
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }
}
